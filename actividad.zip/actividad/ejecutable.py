
from sobrescritura2 import hola
from sobrescritura1 import hola2


#Herencia
hola = hola()
hola2 = hola2()


hola.saludo()
hola2.saludo()

#Sobreescritura
def despido():
    print("Adios")


def despido():
    print("Adios2")

despido()