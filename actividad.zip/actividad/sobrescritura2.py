class hola:
    def saludo(self):
        print("hola")