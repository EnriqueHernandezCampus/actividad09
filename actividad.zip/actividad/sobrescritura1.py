class hola2:
    def saludo(self):
        print("hola2")